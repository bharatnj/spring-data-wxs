/**
 * 
 */
package com.springuniverse.social.twitter;

import java.util.concurrent.Callable;

/**
 * @author bnepal
 *
 */
public class TwitterThread implements Callable<String>{

	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

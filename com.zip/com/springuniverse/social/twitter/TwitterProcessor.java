/**
 * 
 */
package com.springuniverse.social.twitter;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.stereotype.Component;

import com.springuniverse.social.config.TwitterConfig;

/**
 * @author bnepal
 *
 */
@Component
@Slf4j
public class TwitterProcessor {
	
	@Autowired
	private ConcurrentHashMap<String, Twitter> twitterConnections;
	
	@Autowired
	private TwitterConfig twitterConfig;
	
	@Scheduled(fixedRate = 5000)
	public void retweet()
	{
		log.info("Checking new tweets for all users");
		for(String username: twitterConnections.keySet())
		{
			for(String retweetFrom: twitterConfig.getRetweetFrom())
			{
				log.info("Checking new tweets for user " + retweetFrom);
				/*List<Tweet> tweets = twitterConnections.get(username).timelineOperations().getUserTimeline(retweetFrom);
				for(Tweet tweet: tweets)
				{
					if(!tweet.isRetweeted())
					{
						tweet.setFavorited(true);
						tweet.setRetweeted(true);
					}
				}*/
			}
		}
	}

}

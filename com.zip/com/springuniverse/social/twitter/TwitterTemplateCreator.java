/**
 * 
 */
package com.springuniverse.social.twitter;

/**
 * @author bnepal
 *
 */
public class TwitterTemplateCreator {

}

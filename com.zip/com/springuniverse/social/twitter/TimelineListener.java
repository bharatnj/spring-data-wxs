/**
 * 
 */
package com.springuniverse.social.twitter;

/**
 * @author bnepal
 *
 */
public class TimelineListener {

}

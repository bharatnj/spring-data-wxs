/**
 * 
 */
package com.springuniverse.social.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springuniverse.social.model.TwitterUser;

/**
 * @author bnepal
 *
 */
public interface TwitterUserRepository extends JpaRepository<TwitterUser, Integer>{

}

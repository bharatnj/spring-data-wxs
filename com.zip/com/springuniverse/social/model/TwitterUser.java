/**
 * 
 */
package com.springuniverse.social.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * @author bnepal
 *
 */
@Entity
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TwitterUser {
	
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;
	String userName;
	String password;

}

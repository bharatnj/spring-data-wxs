/**
 * 
 */
package com.springuniverse.social.config;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.impl.TwitterTemplate;

/**
 * @author bnepal
 *
 */
@Configuration
@EnableConfigurationProperties({TwitterConfig.class})
public class SocialConfiguration {
	
	@Autowired
	private TwitterConfig twitterConfig;
	
	@Bean
	public ConcurrentHashMap<String, Twitter> twitterConnections()
	{
		ConcurrentHashMap<String, Twitter> twitterConnections = new ConcurrentHashMap<>();
		/*for(User user: twitterConfig.getUsers())
		{
			TwitterTemplate twitterTemplate = 
			         new TwitterTemplate(user.getUserName(), user.getPassword());
			twitterConnections.put(user.getUserName(), twitterTemplate);
		}*/
		return twitterConnections;
	}

}

/**
 * 
 */
package com.springuniverse.social.config;

import java.util.List;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author bnepal
 *
 */
@ConfigurationProperties(prefix = "twitter")
@FieldDefaults(level=AccessLevel.PRIVATE)
@Data
public class TwitterConfig {
	
	List<User> users;
	List<String> retweetFrom;

}

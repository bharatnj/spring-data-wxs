/**
 * 
 */
package com.springuniverse.social.config;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * @author bnepal
 *
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class User {

	String userName;
	String password;
}
